# suture-trace

Two-line OpenTelemetry setup that sends AI calls to Suture. Docs: https://suture.nexprove.com/docs/tracing

```ts
import { initSuture, suture } from 'suture-trace';
initSuture({ apiKey: process.env.SUTURE_API_KEY });
const res = await suture('post-writer', () => openai.chat.completions.create({ ... }));
```

`pnpm -F suture-trace test` · `pnpm -F suture-trace demo` (sends one trace to a local receiver and prints what Suture stores).
